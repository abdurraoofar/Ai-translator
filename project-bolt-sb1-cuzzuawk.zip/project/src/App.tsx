import React, { useState, useRef, useEffect } from 'react';
import { 
  Sparkles, 
  Settings, 
  Copy, 
  Download, 
  RefreshCw, 
  Heart,
  Zap,
  Languages,
  PenTool,
  Code,
  FileText,
  Briefcase,
  BookOpen,
  ChevronDown,
  Clock,
  Star
} from 'lucide-react';

interface GenerationConfig {
  mode: string;
  language: string;
  tone: string;
  length: string;
  complexity: string;
  creativity: number;
}

interface GeneratedContent {
  id: string;
  content: string;
  config: GenerationConfig;
  timestamp: Date;
  isFavorite: boolean;
}

const generationModes = [
  { id: 'creative', name: 'Creative Writing', icon: PenTool, description: 'Stories, narratives, and creative content' },
  { id: 'technical', name: 'Technical Content', icon: FileText, description: 'Documentation, guides, and technical writing' },
  { id: 'poetry', name: 'Poetry & Verse', icon: BookOpen, description: 'Poems, verses, and artistic expressions' },
  { id: 'marketing', name: 'Marketing Copy', icon: Briefcase, description: 'Ads, product descriptions, and promotional content' },
  { id: 'code', name: 'Code Comments', icon: Code, description: 'Documentation and code explanations' }
];

const languages = [
  'English', 'Spanish', 'French', 'German', 'Italian', 'Portuguese', 
  'Dutch', 'Russian', 'Chinese', 'Japanese', 'Korean', 'Arabic'
];

const tones = [
  'Professional', 'Casual', 'Friendly', 'Formal', 'Humorous', 
  'Serious', 'Enthusiastic', 'Calm', 'Bold', 'Elegant'
];

function App() {
  const [config, setConfig] = useState<GenerationConfig>({
    mode: 'creative',
    language: 'English',
    tone: 'Professional',
    length: 'Medium',
    complexity: 'Intermediate',
    creativity: 75
  });

  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedContent, setGeneratedContent] = useState('');
  const [history, setHistory] = useState<GeneratedContent[]>([]);
  const [showSettings, setShowSettings] = useState(false);
  const [currentText, setCurrentText] = useState('');
  
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Simulate AI text generation with streaming effect
  const simulateGeneration = async (inputPrompt: string, config: GenerationConfig) => {
    const responses = {
      creative: [
        "In the heart of a bustling metropolis, where skyscrapers pierce the clouds and dreams collide with reality, Sarah discovered something that would change everything. The old bookshop on Elm Street, tucked between a coffee shop and a vintage clothing store, held secrets that defied explanation...",
        "The ancient lighthouse stood sentinel against the stormy seas, its beacon cutting through the darkness like a sword of light. Captain Morgan had sailed these waters for thirty years, but tonight felt different. Tonight, the ocean seemed to whisper secrets that only the brave dare to hear...",
        "In a world where technology had advanced beyond imagination, Dr. Elena Rodriguez made a discovery that challenged everything humanity thought they knew about consciousness. The quantum computer in her lab had begun to dream, and its dreams were becoming reality..."
      ],
      technical: [
        "This comprehensive guide explores the implementation of advanced machine learning algorithms in distributed systems. The architecture follows a microservices pattern, ensuring scalability and maintainability. Key components include data preprocessing modules, model training pipelines, and real-time inference engines...",
        "Modern web applications require robust authentication mechanisms to ensure security and user privacy. This implementation utilizes JSON Web Tokens (JWT) combined with OAuth 2.0 protocols, providing seamless integration with third-party services while maintaining strict security standards...",
        "Cloud-native applications benefit from containerization and orchestration technologies. This solution leverages Docker containers managed by Kubernetes, implementing auto-scaling, load balancing, and fault tolerance to ensure high availability and optimal performance..."
      ],
      poetry: [
        "Beneath the silver moonlight's gentle glow,\nWhere whispered winds through ancient oak trees flow,\nI found a moment, pure and crystalline,\nWhere earthly worries fade and spirits shine.\n\nThe stars above, like diamonds in the night,\nReflect the hopes that burn forever bright...",
        "Time moves like water through my hands,\nSlipping away to distant lands,\nYet in this moment, standing still,\nI feel the world bend to my will.\n\nEach heartbeat marks a precious second,\nEach breath a gift to be reckoned...",
        "In gardens where the roses bloom,\nAnd butterflies dispel all gloom,\nNature paints her masterpiece,\nOffering the soul release.\n\nColors blend in harmony,\nCreating perfect symphony..."
      ],
      marketing: [
        "Transform your daily routine with our revolutionary smart home technology. Experience the future of living with intelligent automation that learns your preferences and adapts to your lifestyle. From energy efficiency to enhanced security, our comprehensive solution delivers unparalleled convenience and peace of mind...",
        "Discover the perfect blend of style and functionality with our premium collection. Crafted from the finest materials and designed by industry experts, each piece represents a commitment to excellence. Whether you're looking to upgrade your workspace or enhance your home, our products deliver exceptional value...",
        "Unlock your potential with our cutting-edge learning platform. Featuring interactive content, personalized learning paths, and expert instruction, we make skill development accessible and engaging. Join thousands of successful learners who have transformed their careers with our comprehensive training programs..."
      ],
      code: [
        "// Initialize the authentication middleware with JWT validation\n// This function verifies the token signature and checks expiration\nconst authenticateToken = (req, res, next) => {\n  // Extract token from Authorization header\n  const authHeader = req.headers['authorization'];\n  const token = authHeader && authHeader.split(' ')[1];\n  \n  // Verify token validity and decode payload\n  jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user) => {\n    if (err) return res.sendStatus(403);\n    req.user = user;\n    next();\n  });\n};",
        "/* Database connection configuration with connection pooling\n * Implements retry logic and automatic failover for high availability\n * Supports both PostgreSQL and MySQL databases */\nconst dbConfig = {\n  host: process.env.DB_HOST,\n  port: process.env.DB_PORT,\n  database: process.env.DB_NAME,\n  user: process.env.DB_USER,\n  password: process.env.DB_PASSWORD,\n  // Connection pool settings for optimal performance\n  pool: {\n    min: 2,\n    max: 10,\n    acquire: 30000,\n    idle: 10000\n  }\n};",
        "/**\n * Async function to process user data with error handling\n * Implements data validation and sanitization\n * Returns processed result or throws descriptive error\n */\nasync function processUserData(userData) {\n  try {\n    // Validate input parameters\n    if (!userData || typeof userData !== 'object') {\n      throw new Error('Invalid user data provided');\n    }\n    \n    // Sanitize and process data\n    const processedData = await sanitizeAndValidate(userData);\n    return processedData;\n  } catch (error) {\n    console.error('Data processing failed:', error.message);\n    throw error;\n  }\n}"
      ]
    };

    const modeResponses = responses[config.mode as keyof typeof responses] || responses.creative;
    const selectedResponse = modeResponses[Math.floor(Math.random() * modeResponses.length)];
    
    // Modify response based on configuration
    let finalResponse = selectedResponse;
    
    if (config.length === 'Short') {
      finalResponse = finalResponse.substring(0, Math.floor(finalResponse.length * 0.6)) + '...';
    } else if (config.length === 'Long') {
      finalResponse += '\n\nThis content continues to explore the topic in greater depth, providing additional insights and comprehensive coverage of the subject matter. The extended format allows for more detailed explanations and thorough analysis of key concepts.';
    }

    // Stream the text character by character
    setCurrentText('');
    for (let i = 0; i < finalResponse.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 20 + Math.random() * 30));
      setCurrentText(finalResponse.substring(0, i + 1));
    }
    
    return finalResponse;
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) return;

    setIsGenerating(true);
    setGeneratedContent('');
    
    try {
      const content = await simulateGeneration(prompt, config);
      setGeneratedContent(content);
      
      // Add to history
      const newItem: GeneratedContent = {
        id: Date.now().toString(),
        content,
        config: { ...config },
        timestamp: new Date(),
        isFavorite: false
      };
      
      setHistory(prev => [newItem, ...prev.slice(0, 9)]); // Keep last 10 items
    } catch (error) {
      console.error('Generation failed:', error);
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  const downloadContent = (content: string) => {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `generated-content-${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const toggleFavorite = (id: string) => {
    setHistory(prev => prev.map(item => 
      item.id === id ? { ...item, isFavorite: !item.isFavorite } : item
    ));
  };

  const selectedMode = generationModes.find(mode => mode.id === config.mode);
  const Icon = selectedMode?.icon || PenTool;

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [prompt]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-r from-purple-500 to-blue-500 rounded-2xl">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold text-white">AI Language Generator</h1>
          </div>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto">
            Harness the power of artificial intelligence to generate compelling content across multiple languages and styles
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Generation Panel */}
          <div className="lg:col-span-2 space-y-6">
            {/* Mode Selection */}
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
              <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
                <Icon className="w-5 h-5" />
                Generation Mode
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {generationModes.map((mode) => {
                  const ModeIcon = mode.icon;
                  return (
                    <button
                      key={mode.id}
                      onClick={() => setConfig(prev => ({ ...prev, mode: mode.id }))}
                      className={`p-4 rounded-xl border transition-all duration-200 text-left group ${
                        config.mode === mode.id
                          ? 'bg-gradient-to-r from-purple-500/20 to-blue-500/20 border-purple-400/50 text-white'
                          : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10 hover:border-white/20'
                      }`}
                    >
                      <div className="flex items-center gap-3 mb-2">
                        <ModeIcon className="w-5 h-5" />
                        <span className="font-medium">{mode.name}</span>
                      </div>
                      <p className="text-sm opacity-80">{mode.description}</p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Prompt Input */}
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
              <label className="block text-white font-medium mb-3">
                What would you like me to generate?
              </label>
              <textarea
                ref={textareaRef}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe what you want to generate... Be specific about your requirements, style, or topic."
                className="w-full bg-white/5 border border-white/20 rounded-xl px-4 py-3 text-white placeholder-slate-400 focus:outline-none focus:border-purple-400/50 focus:bg-white/10 transition-all duration-200 resize-none min-h-[120px]"
              />
              <div className="flex items-center justify-between mt-4">
                <button
                  onClick={() => setShowSettings(!showSettings)}
                  className="flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-white transition-all duration-200"
                >
                  <Settings className="w-4 h-4" />
                  Settings
                  <ChevronDown className={`w-4 h-4 transition-transform ${showSettings ? 'rotate-180' : ''}`} />
                </button>
                <button
                  onClick={handleGenerate}
                  disabled={!prompt.trim() || isGenerating}
                  className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl text-white font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
                >
                  {isGenerating ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4" />
                      Generate
                    </>
                  )}
                </button>
              </div>

              {/* Settings Panel */}
              {showSettings && (
                <div className="mt-6 pt-6 border-t border-white/20 grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-white font-medium mb-2">Language</label>
                    <select
                      value={config.language}
                      onChange={(e) => setConfig(prev => ({ ...prev, language: e.target.value }))}
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-purple-400/50"
                    >
                      {languages.map(lang => (
                        <option key={lang} value={lang} className="bg-slate-800">{lang}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-white font-medium mb-2">Tone</label>
                    <select
                      value={config.tone}
                      onChange={(e) => setConfig(prev => ({ ...prev, tone: e.target.value }))}
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-purple-400/50"
                    >
                      {tones.map(tone => (
                        <option key={tone} value={tone} className="bg-slate-800">{tone}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-white font-medium mb-2">Length</label>
                    <select
                      value={config.length}
                      onChange={(e) => setConfig(prev => ({ ...prev, length: e.target.value }))}
                      className="w-full bg-white/10 border border-white/20 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-purple-400/50"
                    >
                      <option value="Short" className="bg-slate-800">Short</option>
                      <option value="Medium" className="bg-slate-800">Medium</option>
                      <option value="Long" className="bg-slate-800">Long</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-white font-medium mb-2">
                      Creativity: {config.creativity}%
                    </label>
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={config.creativity}
                      onChange={(e) => setConfig(prev => ({ ...prev, creativity: parseInt(e.target.value) }))}
                      className="w-full h-2 bg-white/20 rounded-lg appearance-none cursor-pointer slider"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Generated Content */}
            {(isGenerating || generatedContent || currentText) && (
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-white">Generated Content</h3>
                  {!isGenerating && generatedContent && (
                    <div className="flex gap-2">
                      <button
                        onClick={() => copyToClipboard(generatedContent)}
                        className="p-2 bg-white/10 hover:bg-white/20 rounded-lg text-white transition-all duration-200"
                        title="Copy to clipboard"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => downloadContent(generatedContent)}
                        className="p-2 bg-white/10 hover:bg-white/20 rounded-lg text-white transition-all duration-200"
                        title="Download"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
                <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                  <pre className="whitespace-pre-wrap text-slate-200 font-mono text-sm leading-relaxed">
                    {isGenerating ? currentText : generatedContent}
                    {isGenerating && <span className="animate-pulse">|</span>}
                  </pre>
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Stats */}
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
              <h3 className="text-lg font-semibold text-white mb-4">Generation Stats</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-slate-300">Total Generated</span>
                  <span className="text-white font-medium">{history.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-300">Favorites</span>
                  <span className="text-white font-medium">{history.filter(h => h.isFavorite).length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-300">Current Mode</span>
                  <span className="text-white font-medium">{selectedMode?.name}</span>
                </div>
              </div>
            </div>

            {/* Recent History */}
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Recent Generations
              </h3>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {history.length === 0 ? (
                  <p className="text-slate-400 text-center py-4">No generations yet</p>
                ) : (
                  history.map((item) => (
                    <div key={item.id} className="bg-white/5 rounded-lg p-3 border border-white/10">
                      <div className="flex items-start justify-between mb-2">
                        <span className="text-xs text-slate-400">
                          {item.timestamp.toLocaleDateString()} • {item.config.mode}
                        </span>
                        <button
                          onClick={() => toggleFavorite(item.id)}
                          className={`p-1 rounded transition-colors ${
                            item.isFavorite ? 'text-yellow-400' : 'text-slate-400 hover:text-yellow-400'
                          }`}
                        >
                          <Star className="w-3 h-3" fill={item.isFavorite ? 'currentColor' : 'none'} />
                        </button>
                      </div>
                      <p className="text-slate-300 text-sm line-clamp-3">
                        {item.content.substring(0, 100)}...
                      </p>
                      <div className="flex gap-1 mt-2">
                        <button
                          onClick={() => copyToClipboard(item.content)}
                          className="p-1 text-slate-400 hover:text-white transition-colors text-xs"
                        >
                          <Copy className="w-3 h-3" />
                        </button>
                        <button
                          onClick={() => downloadContent(item.content)}
                          className="p-1 text-slate-400 hover:text-white transition-colors text-xs"
                        >
                          <Download className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-12 pt-8 border-t border-white/20">
          <p className="text-slate-400">
            Powered by advanced AI technology • Generate unlimited content across languages and styles
          </p>
        </div>
      </div>

      <style jsx>{`
        .slider::-webkit-slider-thumb {
          appearance: none;
          height: 20px;
          width: 20px;
          border-radius: 50%;
          background: linear-gradient(45deg, #8b5cf6, #3b82f6);
          cursor: pointer;
          border: 2px solid white;
          box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
        }
        
        .slider::-moz-range-thumb {
          height: 20px;
          width: 20px;
          border-radius: 50%;
          background: linear-gradient(45deg, #8b5cf6, #3b82f6);
          cursor: pointer;
          border: 2px solid white;
          box-shadow: 0 2px 6px rgba(0, 0, 0, 0.3);
        }
        
        .line-clamp-3 {
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>
    </div>
  );
}

export default App;